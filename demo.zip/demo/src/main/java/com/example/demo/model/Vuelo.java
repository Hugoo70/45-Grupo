package com.example.demo.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vuelos")
public class Vuelo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private LocalDate fecha;

    @NotBlank(message = "Mercancía obligatoria")
    @Column(nullable = false)
    private String mercancia;

    @NotBlank(message = "Modelo de avión obligatorio")
    @Column(nullable = false)
    private String modelo;
    
    @NotBlank(message = "Ubicación de salida obligatoria")
    @Column(nullable = false)
    private String ubiSalida;

    @NotBlank(message = "Hora de salida obligatoria")
    @Column(nullable = false)
    private String horaSalida;

    @NotBlank(message = "Ubicación de llegada obligatoria")
    @Column(nullable = false)
    private String ubiLlegada;

    @NotBlank(message = "Hora de llegada obligatoria")
    @Column(nullable = false)
    private String horaLlegada;

    @NotBlank(message = "Horas del mes obligatorio")
    @Column(nullable = false)
    private String horasMes;

    @NotBlank(message = "Horas del año obligatorio")
    @Column(nullable = false)
    private String horasAnio;

    @NotBlank(message = "Horas totales obligatorias")
    @Column(nullable = false)
    private String horasTotales;

    @NotBlank(message = "Anticipo obligatorio")
    @Column(nullable = false)
    private String anticipo;

    @NotBlank(message = "Líquido obligatorio")
    @Column(nullable = false)
    private String liquido;

    @NotBlank(message = "Gasolina obligatoria")
    @Column(nullable = false)
    private String gasolina;

    @NotBlank(message = "Hotel obligatorio")
    @Column(nullable = false)
    private String hotel;

    @ManyToMany(mappedBy = "vuelos", cascade = CascadeType.ALL, fetch = FetchType.LAZY) 
    private List<Usuario> usuarios = new ArrayList<>();
}
